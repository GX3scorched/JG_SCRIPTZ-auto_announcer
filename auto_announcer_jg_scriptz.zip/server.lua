-- server.lua
-- Auto announcer (JG_SCRIPTZ)

local currentIndex = 1
local cfg = Config

local function sendAnnouncement(text)
    local prefix = cfg.Prefix or ""
    TriggerClientEvent('chat:addMessage', -1, {
        args = { prefix .. " " .. text }
    })
end

Citizen.CreateThread(function()
    while true do
        local announcements = cfg.Announcements or {}
        if #announcements == 0 then
            Citizen.Wait(60000)
        else
            local announcement = announcements[currentIndex]
            if announcement and announcement.text then
                sendAnnouncement(announcement.text)
                local delay = tonumber(announcement.delay) or 300
                Citizen.Wait(delay * 1000)
                currentIndex = currentIndex + 1
                if currentIndex > #announcements then currentIndex = 1 end
            else
                currentIndex = currentIndex + 1
                if currentIndex > #announcements then currentIndex = 1 end
                Citizen.Wait(1000)
            end
        end
    end
end)
