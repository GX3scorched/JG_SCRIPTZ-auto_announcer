-- config.lua
-- Made by JG_SCRIPTZ

Config = {}

-- Announcements: each entry has text (string) and delay (seconds) before next announcement.
-- The server will loop through them in order and repeat.
Config.Announcements = {
    { text = "Welcome to the server! Be respectful and have fun.", delay = 300 },
    { text = "Remember to read the rules on the forum.", delay = 600 },
    { text = "Need help? Ask a staff member if one is online.", delay = 450 }
}

-- Chat message settings
Config.Prefix = "^1[ANNOUNCER]^7"
