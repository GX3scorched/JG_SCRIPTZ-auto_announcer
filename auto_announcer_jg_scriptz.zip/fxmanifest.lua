fx_version 'cerulean'
game 'gta5'

author 'JG_SCRIPTZ'
description 'Auto Announcer - ESX (made by JG_SCRIPTZ) - configurable announcements with ox_lib + ox_target support'
version '1.1.0'

server_script 'server.lua'
shared_script 'config.lua'

dependencies {
    'es_extended',
    'ox_lib',
    'ox_target'
}
